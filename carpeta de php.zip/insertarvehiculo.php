<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $ano = $_POST['ano'];
    $placa = $_POST['placa'];
    $color = $_POST['color'];

    $sql = "INSERT INTO vehiculo (marca, modelo, ano, placa, color) VALUES ('$marca', '$modelo', '$ano', '$placa', '$color')";
    if ($conex->query($sql) === TRUE) {
        echo '¡Registro insertado!';
    } else {
        echo 'Error: ' . $conex->error;
    }
}
?>
