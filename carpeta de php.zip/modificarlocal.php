<?php
include 'conexion.php';

$cedula = $_POST['cedula'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$fecha_nacimiento = $_POST['fecha_nacimiento'];
$nacionalidad = $_POST['nacionalidad'];
$telefono = $_POST['telefono'];
$correo_electronico = $_POST['correo_electronico'];

$consulta = "UPDATE participantes SET nombre='$nombre', apellido='$apellido', fecha_nacimiento='$fecha_nacimiento', nacionalidad='$nacionalidad', telefono='$telefono', correo_electronico='$correo_electronico' WHERE cedula='$cedula'";
$resultado = mysqli_query($conexion, $consulta);

if ($resultado) {
    echo "Registro actualizado correctamente";
} else {
    echo "Error al actualizar el registro: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>
