<?php
include 'conexion.php';

$cedula = $_POST['cedula'];

$consulta = "DELETE FROM participantes WHERE cedula='$cedula'";
$resultado = mysqli_query($conexion, $consulta);

if ($resultado) {
    echo "Registro eliminado correctamente";
} else {
    echo "Error al eliminar el registro: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>
