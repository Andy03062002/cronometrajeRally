<?php
include 'conexion.php'; // Incluir archivo de conexión

// Verificar si se recibió la cédula por GET
if (isset($_GET['cedula'])) {
    $cedula = $_GET['cedula'];

    // Consulta SQL para obtener los datos del participante por cédula
    $consulta = "SELECT * FROM PARTICIPANTES WHERE cedula = '$cedula'";
    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
        // Verificar si se encontraron resultados
        if (mysqli_num_rows($resultado) > 0) {
            $row = mysqli_fetch_assoc($resultado);
            // Formar el string con los datos separados por comas y punto y coma al final
            echo $row['cedula'] . ',' . $row['nombre'] . ',' . $row['apellido'] . ',' . $row['fecha_nacimiento'] . ',' . $row['nacionalidad'] . ',' . $row['telefono'] . ';';
        } else {
            echo "No se encontró ningún participante con esa cédula";
        }
    } else {
        echo "Error al ejecutar la consulta: " . mysqli_error($conexion);
    }
} else {
    echo "No se recibió la cédula";
}

mysqli_close($conexion); // Cerrar conexión
?>
