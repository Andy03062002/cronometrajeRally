<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include 'conexion.php';

$cedula = $_POST['cedula'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$fecha_nacimiento = $_POST['fecha_nacimiento'];
$nacionalidad = $_POST['nacionalidad'];
$genero = $_POST['genero'];
$telefono = $_POST['telefono'];
$correo_electronico = $_POST['correo_electronico'];

// Verificar si la cédula ya existe
$consulta_verificar = "SELECT * FROM Ocupante WHERE cedula = '$cedula'";
$resultado = mysqli_query($conex, $consulta_verificar);

if (mysqli_num_rows($resultado) > 0) {
    echo "Error: La cédula ya existe.";
} else {
    $consulta = "INSERT INTO Ocupante (cedula, nombre, apellido, fecha_nacimiento, nacionalidad,genero, telefono, correo_electronico) VALUES ('$cedula', '$nombre', '$apellido', '$fecha_nacimiento', '$nacionalidad','$genero', '$telefono', '$correo_electronico')";
    mysqli_query($conex, $consulta) or die(mysqli_error($conex));
    echo "Datos insertados correctamente.";
}

mysqli_close($conexion);
?>
