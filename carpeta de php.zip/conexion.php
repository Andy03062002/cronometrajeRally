<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$dbhost = 'localhost';
$dbuser = 'id22365877_admiclients';
$dbpass = 'AdmiClients03.';
$dbname = 'id22365877_pruebasoap';

// Crear conexión
$conex = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Verificar conexión
if ($conex->connect_errno) {
    die("Lo sentimos, no hay conexión: (" . $conex->connect_errno . ") " . $conex->connect_error);
}else {
        echo ("conectado");
        }

?>
