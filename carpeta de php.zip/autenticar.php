<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $conex->real_escape_string($_POST['usuario']);
    $password = $conex->real_escape_string($_POST['password']);

    $sql = "";
    $result = $conex->query($sql);

    if ($result->num_rows > 0) {
        echo 'success';
    } else {
        echo 'fail';
    }
}
?>
